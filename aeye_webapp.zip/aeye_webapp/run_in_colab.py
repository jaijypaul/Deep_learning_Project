# ============================================================
# Run the A-eye web page from Google Colab (paste into one cell)
# ------------------------------------------------------------
# 1. Upload the whole aeye_webapp folder to MyDrive/aeye_webapp
# 2. Run this cell, then click the printed link.
#    The link only works in your own logged-in browser session.
# ============================================================
from google.colab import drive
drive.mount('/content/drive')

!pip -q install fastapi uvicorn python-multipart PyWavelets

import os, subprocess, time
APP_DIR = '/content/drive/MyDrive/aeye_webapp'
env = {**os.environ,
       'DETECTOR_CHECKPOINT': '/content/drive/MyDrive/Data/models_v4/mlp_detector_v4.pt',
       'DETECTOR_METRICS':    '/content/drive/MyDrive/Data/results_v4/metrics_v4.json'}

server = subprocess.Popen(['uvicorn', 'app:app', '--host', '0.0.0.0', '--port', '8000'],
                          cwd=APP_DIR, env=env,
                          stdout=open('/content/aeye_server.log', 'w'), stderr=subprocess.STDOUT)
time.sleep(6)
print(open('/content/aeye_server.log').read())   # should say "model loaded"

from google.colab.output import eval_js
print('Open the detector:', eval_js("google.colab.kernel.proxyPort(8000)"))

# To stop the server later:  server.terminate()
