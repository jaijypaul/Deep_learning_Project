"""
app.py — web server for the A-eye real-vs-AI video detector.

Run:   uvicorn app:app --host 0.0.0.0 --port 8000
Open:  http://localhost:8000

Environment variables (optional):
  DETECTOR_CHECKPOINT  path to mlp_detector_v4.pt   (default: models/mlp_detector_v4.pt)
  DETECTOR_METRICS     path to metrics_v4.json      (default: models/metrics_v4.json)
  MAX_UPLOAD_MB        largest accepted upload      (default: 300)
"""
import json, os, tempfile, threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse

import detector

BASE = Path(__file__).resolve().parent
CHECKPOINT = Path(os.environ.get("DETECTOR_CHECKPOINT", BASE / "models" / "mlp_detector_v4.pt"))
METRICS = Path(os.environ.get("DETECTOR_METRICS", BASE / "models" / "metrics_v4.json"))
MAX_BYTES = int(os.environ.get("MAX_UPLOAD_MB", 300)) * 1024 * 1024

state = {"detector": None, "error": None, "metrics": None}
analysis_lock = threading.Lock()   # one video at a time keeps memory use predictable


@asynccontextmanager
async def lifespan(_app):
    try:
        state["detector"] = detector.Detector(CHECKPOINT)
        print(f"[A-eye] model loaded from {CHECKPOINT} | threshold = {state['detector'].threshold:.3f}")
    except Exception as e:  # keep the page up so it can show what is wrong
        state["error"] = str(e)
        print(f"[A-eye] MODEL NOT LOADED: {e}")
    if METRICS.exists():
        try:
            state["metrics"] = json.loads(METRICS.read_text())
        except Exception:
            pass
    yield


app = FastAPI(title="A-eye video detector", lifespan=lifespan)


@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")


@app.get("/api/model")
def model_info():
    det = state["detector"]
    m = state["metrics"] or {}
    return {
        "ready": det is not None,
        "error": state["error"],
        "model": det.info if det else None,
        "test_metrics": {k: m[k] for k in ("accuracy", "precision", "recall", "f1", "roc_auc", "num_test")
                         if k in m} or None,
        "accepted_types": sorted(detector.VIDEO_EXTS),
        "max_upload_mb": MAX_BYTES // (1024 * 1024),
    }


@app.post("/api/analyze")
def analyze(file: UploadFile = File(...)):
    # Plain `def` (not async): FastAPI runs it in a worker thread, so the
    # CPU-heavy feature extraction does not block the server.
    det = state["detector"]
    if det is None:
        raise HTTPException(503, f"The model is not loaded: {state['error']}")

    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in detector.VIDEO_EXTS:
        raise HTTPException(415, f"Unsupported file type '{suffix or 'none'}'. "
                                 f"Use one of: {', '.join(sorted(detector.VIDEO_EXTS))}.")

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        size = 0
        while chunk := file.file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_BYTES:
                raise HTTPException(413, f"The video is larger than {MAX_BYTES // (1024 * 1024)} MB.")
            tmp.write(chunk)
        tmp.close()
        with analysis_lock:
            result = det.analyze(tmp.name)
        result["filename"] = file.filename
        result["size_mb"] = round(size / (1024 * 1024), 2)
        return result
    except HTTPException:
        raise
    except (IOError, ValueError) as e:
        raise HTTPException(422, str(e))
    except Exception as e:
        raise HTTPException(500, f"Analysis failed: {e}")
    finally:
        tmp.close()
        try:
            os.unlink(tmp.name)          # uploaded videos are never kept
        except OSError:
            pass
