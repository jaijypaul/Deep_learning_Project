"""
detector.py — inference core for the A-eye v4 real-vs-AI video detector.

The feature-extraction code between the two "COPIED FROM NOTEBOOK" markers is
taken verbatim from ie643_project3 (sections 7–10), so a video uploaded through
the web page produces exactly the same
feature vector the MLP was trained on.
Do not edit those functions unless you retrain the model.
"""
from pathlib import Path
import base64, time

import cv2
import numpy as np
import pywt
import torch
import torch.nn as nn

# ------------------------------------------------------------------
# Settings — must match FEATURE_CONFIG in the training notebook.
# They are checked against the checkpoint when it is loaded.
# ------------------------------------------------------------------
FEATURE_VERSION = "v4_freq_temporal_wavelet"
NUM_SEGMENTS, FRAMES_PER_SEGMENT, FRAME_STRIDE = 4, 8, 1
CROP_SIZE, N_CROPS = 256, 5
NUM_BINS = 64
HIDDEN, DROPOUT = (256, 128, 64), 0.30
VIDEO_EXTS = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}

FEATURE_CONFIG = {
    'feature_version': FEATURE_VERSION, 'num_segments': NUM_SEGMENTS,
    'frames_per_segment': FRAMES_PER_SEGMENT, 'frame_stride': FRAME_STRIDE,
    'crop_size': CROP_SIZE, 'n_crops': N_CROPS, 'num_bins': NUM_BINS,
}

# ====================== COPIED FROM NOTEBOOK (start) ======================
# ============================================================
# 7. Temporal sampling
# ============================================================
def read_temporal_segments(path, num_segments=NUM_SEGMENTS, frames_per_segment=FRAMES_PER_SEGMENT, stride=FRAME_STRIDE):
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise IOError(f'Cannot open video: {path}')

    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    if total < 3:
        cap.release()
        raise ValueError(f'Video has only {total} frames')

    needed = frames_per_segment * stride
    max_start = max(0, total - needed)
    starts = [0] if num_segments == 1 else np.linspace(0, max_start, num_segments).round().astype(int)

    segments = []
    for start in starts:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(start))
        frames = []
        for k in range(needed):
            ok, frame = cap.read()
            if not ok:
                break
            if k % stride == 0:
                frames.append(frame)
        if len(frames) >= 3:
            segments.append(np.stack(frames))
    cap.release()

    if len(segments) == 0:
        raise ValueError(f'Could not read enough frames from {path}')
    return segments, fps


def resize_if_needed(frames, crop_size=CROP_SIZE):
    h, w = frames.shape[1:3]
    if min(h, w) >= crop_size:
        return frames
    scale = crop_size / min(h, w)
    new_w, new_h = int(np.ceil(w * scale)), int(np.ceil(h * scale))
    return np.stack([cv2.resize(f, (new_w, new_h), interpolation=cv2.INTER_CUBIC) for f in frames])


def crop_boxes(h, w, size=CROP_SIZE):
    cy, cx = (h - size) // 2, (w - size) // 2
    qy, qx = max(0, (h-size)//4), max(0, (w-size)//4)
    raw = [
        (cy, cx),
        (max(0, cy-qy), max(0, cx-qx)),
        (max(0, cy-qy), min(max(0, w-size), cx+qx)),
        (min(max(0, h-size), cy+qy), max(0, cx-qx)),
        (min(max(0, h-size), cy+qy), min(max(0, w-size), cx+qx))
    ]
    out = list(dict.fromkeys(raw))  # remove duplicate boxes, keep order
    return out


def get_crops(frames):
    frames = resize_if_needed(frames)
    h, w = frames.shape[1:3]
    boxes = crop_boxes(h, w)
    crops = [frames[:, y0:y0+CROP_SIZE, x0:x0+CROP_SIZE] for y0, x0 in boxes[:N_CROPS]]
    return crops


# ============================================================
# 8A. FFT helpers
# ============================================================
def make_radial_bins(h, w, num_bins=NUM_BINS):
    yy, xx = np.mgrid[0:h, 0:w]
    yy, xx = yy - h // 2, xx - w // 2
    r = np.sqrt(xx**2 + yy**2)
    r_norm = r / (min(h, w) / 2.0)
    idx = np.floor(r_norm * num_bins).astype(np.int32)
    valid = idx < num_bins
    return idx, valid


def radial_profile(spec, bin_idx, valid, num_bins=NUM_BINS):
    vals, ids = spec[:, valid], bin_idx[valid]
    out = np.zeros((spec.shape[0], num_bins), dtype=np.float32)
    counts = np.bincount(ids, minlength=num_bins)  # identical for every frame, so computed once
    for t in range(spec.shape[0]):
        sums = np.bincount(ids, weights=vals[t], minlength=num_bins)
        out[t] = sums / np.maximum(counts, 1)
    return out


def fft_log_power(frames):
    x = frames.astype(np.float32)
    x = x - x.mean(axis=(1,2), keepdims=True)
    wy, wx = np.hanning(x.shape[1]).astype(np.float32), np.hanning(x.shape[2]).astype(np.float32)
    window = wy[:, None] * wx[None, :]
    x = x * window[None, :, :]
    F = np.fft.fftshift(np.fft.fft2(x, axes=(-2,-1)), axes=(-2,-1))
    power = np.abs(F)**2
    return np.log1p(power).astype(np.float32)


def normalise_profile(p):
    return p - p.mean(axis=1, keepdims=True)


def entropy_from_vector(v):
    v = np.maximum(v, 1e-12)
    p = v / v.sum()
    return float(-(p * np.log(p + 1e-12)).sum())


def temporal_drift(a):
    """Mean absolute frame-to-frame change along axis 0 (zeros if only one frame)."""
    return np.abs(a[1:] - a[:-1]).mean(axis=0) if len(a) > 1 else np.zeros(a.shape[1:], dtype=np.float32)


# ============================================================
# 8B. Non-radial 2-D FFT statistics
# ============================================================
def nonradial_fft_features(spec):
    T, H, W = spec.shape
    yy, xx = np.mgrid[0:H, 0:W]
    yy, xx = yy - H//2, xx - W//2
    r = np.sqrt(xx**2 + yy**2)
    rmax = min(H,W)/2

    low = r < 0.20*rmax
    mid = (r >= 0.20*rmax) & (r < 0.50*rmax)
    high = (r >= 0.50*rmax) & (r < 1.00*rmax)
    horizontal = np.abs(yy) <= 0.20*np.maximum(np.abs(xx), 1)
    vertical = np.abs(xx) <= 0.20*np.maximum(np.abs(yy), 1)

    feats = []
    for s in spec:
        total = s.sum() + 1e-8
        low_e, mid_e, high_e = s[low].sum() / total, s[mid].sum() / total, s[high].sum() / total
        centroid = (s * r).sum() / total / rmax
        ent = entropy_from_vector(s.ravel())
        h_e, v_e = s[horizontal].sum(), s[vertical].sum()
        anis = (h_e-v_e) / (h_e+v_e+1e-8)
        q1, q2 = s[:H//2, :W//2].sum() / total, s[:H//2, W//2:].sum() / total
        q3, q4 = s[H//2:, :W//2].sum() / total, s[H//2:, W//2:].sum() / total
        hl_ratio = s[high].mean() / (s[low].mean()+1e-8)
        feats.append([low_e, mid_e, high_e, centroid, ent, anis, q1, q2, q3, q4, hl_ratio])
    return np.asarray(feats, dtype=np.float32)


# ============================================================
# 8C. High-frequency residual features
# ============================================================
def residual_features(gray):
    residual = np.asarray([f - cv2.GaussianBlur(f, (0,0), sigmaX=1.0) for f in gray], dtype=np.float32)
    spec = fft_log_power(residual)
    bin_idx, valid = make_radial_bins(gray.shape[1], gray.shape[2])
    prof = radial_profile(spec, bin_idx, valid)
    prof_n = normalise_profile(prof)

    rms = np.sqrt(np.mean(residual**2, axis=(1,2)))
    std = residual.std(axis=(1,2))
    abs_mean = np.abs(residual).mean(axis=(1,2))
    radial_mean, radial_std = prof_n.mean(axis=0), prof_n.std(axis=0)
    drift = temporal_drift(prof_n)

    scalar = np.array([rms.mean(), rms.std(), std.mean(), std.std(), abs_mean.mean(), abs_mean.std()], dtype=np.float32)
    return np.concatenate([radial_mean, radial_std, drift, scalar]).astype(np.float32)


# ============================================================
# 8D. Wavelet features
# ============================================================
def wavelet_features(gray):
    feats = []
    for f in gray:
        coeffs = pywt.wavedec2(f, 'db2', level=2)
        bands = [*coeffs[1], *coeffs[2]]  # (H, V, D) detail bands at both levels
        energies = [np.mean(b**2) for b in bands]
        feats.append(energies)
    feats = np.asarray(feats, dtype=np.float32)

    mean, std = feats.mean(axis=0), feats.std(axis=0)
    drift = temporal_drift(feats)
    return np.concatenate([mean, std, drift]).astype(np.float32)


# ============================================================
# 8E. Chroma frequency features
# ============================================================
def chroma_features(crop_bgr):
    ycc = np.stack([cv2.cvtColor(np.ascontiguousarray(f), cv2.COLOR_BGR2YCrCb) for f in crop_bgr]).astype(np.float32) / 255.0
    out = []
    for ch in [1, 2]:  # Cr, Cb
        channel = ycc[..., ch]
        spec = fft_log_power(channel)
        bin_idx, valid = make_radial_bins(channel.shape[1], channel.shape[2])
        prof = radial_profile(spec, bin_idx, valid)
        prof_n = normalise_profile(prof)
        out += [prof_n.mean(axis=0), prof_n.std(axis=0)]
    return np.concatenate(out).astype(np.float32)


# ============================================================
# 9. Features from one temporal segment/crop
# ============================================================
def segment_crop_features(crop_bgr):
    gray = np.stack([cv2.cvtColor(np.ascontiguousarray(f), cv2.COLOR_BGR2GRAY) for f in crop_bgr]).astype(np.float32) / 255.0
    H, W = gray.shape[1:]
    bin_idx, valid = make_radial_bins(H, W)

    # Main grayscale FFT
    spec = fft_log_power(gray)
    prof = radial_profile(spec, bin_idx, valid)
    prof_n = normalise_profile(prof)
    mean_prof, std_prof, drift_prof = prof_n.mean(axis=0), prof_n.std(axis=0), temporal_drift(prof_n)

    # FFT of frame differences
    frame_diff = gray[1:] - gray[:-1]
    if len(frame_diff) > 0:
        diff_spec = fft_log_power(frame_diff)
        diff_prof = radial_profile(diff_spec, bin_idx, valid).mean(axis=0)
        diff_prof = diff_prof - diff_prof.mean()
    else:
        diff_prof = np.zeros(NUM_BINS, dtype=np.float32)
    radial_features = np.concatenate([mean_prof, std_prof, drift_prof, diff_prof])

    # Non-radial 2-D FFT
    nr = nonradial_fft_features(spec)
    nr_mean, nr_std, nr_drift = nr.mean(axis=0), nr.std(axis=0), temporal_drift(nr)
    nonradial_features = np.concatenate([nr_mean, nr_std, nr_drift])

    # Residual / Wavelet / Chroma
    residual = residual_features(gray)
    wave = wavelet_features(gray)
    chroma = chroma_features(crop_bgr)

    # Temporal scalars
    hf = prof[:, NUM_BINS//2:].mean(axis=1) - prof[:, :NUM_BINS//2].mean(axis=1)
    if len(spec) > 1:
        spec_change = np.abs(spec[1:] - spec[:-1])
        spec_scalars = [np.mean(spec_change), np.std(spec_change), np.max(spec_change)]
    else:
        spec_scalars = [0.0, 0.0, 0.0]
    hf_drift = temporal_drift(hf)
    temporal_scalars = np.array([*spec_scalars, hf.mean(), hf.std(), hf_drift], dtype=np.float32)

    return np.concatenate([radial_features, nonradial_features, residual, wave, chroma, temporal_scalars]).astype(np.float32)


# ============================================================
# 10. Complete video feature extractor
# ============================================================
def extract_video_features_v4(path):
    segments, fps = read_temporal_segments(path)
    segment_features = []
    for seg in segments:
        crops = get_crops(seg)
        crop_features = np.stack([segment_crop_features(crop) for crop in crops])
        # IMPORTANT: retain both mean and spatial variability.
        crop_mean, crop_std = crop_features.mean(axis=0), crop_features.std(axis=0)
        segment_features.append(np.concatenate([crop_mean, crop_std]))
    segment_features = np.stack(segment_features)

    # Temporal aggregation across the whole video.
    video_mean, video_std = segment_features.mean(axis=0), segment_features.std(axis=0)
    feature = np.concatenate([video_mean, video_std]).astype(np.float32)
    return feature
# ====================== COPIED FROM NOTEBOOK (end) ========================


class FreqMLP(nn.Module):
    """Same architecture as section 15 of the notebook."""
    def __init__(self, in_dim, hidden=HIDDEN, dropout=DROPOUT):
        super().__init__()
        layers, d = [], in_dim
        for h in hidden:
            layers.extend([nn.Linear(d, h), nn.BatchNorm1d(h), nn.ReLU(), nn.Dropout(dropout)])
            d = h
        layers.append(nn.Linear(d, 2))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class Detector:
    """Loads mlp_detector_v4.pt once and classifies videos."""

    def __init__(self, checkpoint_path):
        checkpoint_path = Path(checkpoint_path)
        if not checkpoint_path.exists():
            raise FileNotFoundError(
                f"Checkpoint not found: {checkpoint_path}. Copy mlp_detector_v4.pt from "
                f"MyDrive/Data/models_v4/ into the models/ folder.")
        try:
            ckpt = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
        except TypeError:  # older PyTorch without weights_only
            ckpt = torch.load(checkpoint_path, map_location='cpu')

        # Refuse to run if the checkpoint was trained with different feature settings,
        # because the feature vector would silently mean something else.
        mismatched = {k: (ckpt.get(k), v) for k, v in FEATURE_CONFIG.items()
                      if k in ckpt and ckpt.get(k) != v}
        if mismatched:
            raise ValueError(f"Checkpoint feature settings differ from detector.py: {mismatched}")

        hidden = tuple(ckpt.get('hidden', HIDDEN))
        dropout = float(ckpt.get('dropout', DROPOUT))
        self.in_dim = int(ckpt['in_dim'])
        self.model = FreqMLP(self.in_dim, hidden=hidden, dropout=dropout)
        self.model.load_state_dict(ckpt['state_dict'])
        self.model.eval()
        self.mean = _to_numpy(ckpt['mean'])
        self.std = _to_numpy(ckpt['std'])
        self.threshold = float(ckpt['threshold'])
        self.info = {
            'feature_version': ckpt.get('feature_version', FEATURE_VERSION),
            'in_dim': self.in_dim, 'hidden': list(hidden), 'dropout': dropout,
            'threshold': self.threshold, 'checkpoint': checkpoint_path.name,
        }

    @torch.no_grad()
    def predict_feature(self, feature):
        if feature.shape[0] != self.in_dim:
            raise ValueError(f"Feature length {feature.shape[0]} does not match model input {self.in_dim}.")
        x = (feature - self.mean) / self.std            # training-set normalisation only
        x = torch.from_numpy(x.astype(np.float32)).unsqueeze(0)
        probs = torch.softmax(self.model(x), dim=1)[0]
        return float(probs[0]), float(probs[1])

    def analyze(self, path):
        t0 = time.perf_counter()
        meta = video_metadata(path)
        feature = extract_video_features_v4(path)
        if not np.all(np.isfinite(feature)):
            raise ValueError("Feature extraction produced non-finite values for this video.")
        t_feat = time.perf_counter() - t0
        p_real, p_fake = self.predict_feature(feature)
        is_fake = p_fake >= self.threshold
        return {
            'prediction': 'fake' if is_fake else 'real',
            'label': 'AI-generated' if is_fake else 'Real',
            'p_real': p_real, 'p_fake': p_fake, 'threshold': self.threshold,
            # How far from the decision boundary, scaled to 0..1 on each side.
            'margin': (p_fake - self.threshold) / (1 - self.threshold) if is_fake
                      else (self.threshold - p_fake) / self.threshold,
            'video': meta,
            'spectrum': spectrum_preview(path),
            'timing': {'features_s': round(t_feat, 2),
                       'total_s': round(time.perf_counter() - t0, 2)},
            'feature_dim': int(feature.shape[0]),
        }


def _to_numpy(t):
    return t.cpu().numpy() if isinstance(t, torch.Tensor) else np.asarray(t, dtype=np.float32)


def video_metadata(path):
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise IOError("This file could not be opened as a video.")
    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    cap.release()
    return {'frames': frames, 'fps': round(fps, 2), 'width': w, 'height': h,
            'duration_s': round(frames / fps, 2) if fps > 0 else None}


def _png_b64(img):
    ok, buf = cv2.imencode('.png', img)
    return 'data:image/png;base64,' + base64.b64encode(buf.tobytes()).decode('ascii') if ok else None


def spectrum_preview(path):
    """For display only (not used by the classifier): the centre crop of the middle
    segment, its time-averaged log-power FFT, and that spectrum's radial profile."""
    try:
        segments, _ = read_temporal_segments(path)
        seg = segments[len(segments) // 2]
        crop = get_crops(seg)[0]                                    # centre crop, BGR
        gray = np.stack([cv2.cvtColor(np.ascontiguousarray(f), cv2.COLOR_BGR2GRAY)
                         for f in crop]).astype(np.float32) / 255.0
        spec = fft_log_power(gray)
        bin_idx, valid = make_radial_bins(*gray.shape[1:])
        profile = radial_profile(spec, bin_idx, valid).mean(axis=0)

        s = spec.mean(axis=0)
        lo, hi = np.percentile(s, 1), np.percentile(s, 99.8)
        s8 = (np.clip((s - lo) / (hi - lo + 1e-8), 0, 1) * 255).astype(np.uint8)
        spec_img = cv2.applyColorMap(s8, cv2.COLORMAP_VIRIDIS)
        frame_img = np.ascontiguousarray(crop[len(crop) // 2])
        return {'frame_png': _png_b64(frame_img), 'spectrum_png': _png_b64(spec_img),
                'radial_profile': [round(float(v), 4) for v in profile]}
    except Exception:
        return None
