# A-eye — web page for the real vs AI-generated video detector

A small web app around the trained `mlp_detector_v4.pt` from the IE 643 notebook.
You pick a video in the browser, the server extracts the same v4 features
(FFT radial/2-D, residual, wavelet, chroma, temporal — 3068 values), applies the
training-set normalisation stored in the checkpoint, runs the MLP, and compares
P(AI-generated) with the validation-selected threshold.

```
aeye_webapp/
├── app.py            FastAPI server: serves the page, POST /api/analyze, GET /api/model
├── detector.py       Feature extraction (copied verbatim from notebook sections 7–10) + FreqMLP + Detector
├── static/index.html The user interface
├── models/           Put mlp_detector_v4.pt (and optionally metrics_v4.json) here
├── run_in_colab.py   One-cell launcher for Google Colab
└── requirements.txt
```

## Run on your own computer

```bash
cd aeye_webapp
pip install -r requirements.txt
# copy MyDrive/Data/models_v4/mlp_detector_v4.pt   -> models/
# copy MyDrive/Data/results_v4/metrics_v4.json     -> models/   (optional)
uvicorn app:app --host 0.0.0.0 --port 8000
```
Open http://localhost:8000. The terminal should print `model loaded ... threshold = ...`.

## Run in Google Colab (no download of the model needed)

Upload the `aeye_webapp` folder to `MyDrive/aeye_webapp`, paste `run_in_colab.py`
into a cell and run it. It reads the checkpoint straight from
`MyDrive/Data/models_v4/` and prints a link to the page.

## How it stays consistent with training

- `detector.py` contains the notebook's feature functions unchanged, and on start-up
  it checks the checkpoint's feature settings (segments, frames, crop size, bins,
  feature version). If they differ, it refuses to load rather than give wrong answers.
- Normalisation uses only the `mean`/`std` saved from the training split.
- The decision uses the saved validation threshold, not 0.5.
- The "What the detector looks at" panel (crop, spectrum, radial profile) is for
  display only and does not feed the classifier.

## Notes

- Uploaded videos are written to a temp file and deleted right after analysis.
- Analysis takes a few seconds per video on CPU; one video is processed at a time.
- Max upload size defaults to 300 MB (`MAX_UPLOAD_MB` env var).
- API: `curl -F "file=@clip.mp4" http://localhost:8000/api/analyze` returns JSON
  with `prediction`, `p_real`, `p_fake`, `threshold`, video metadata and timing.
